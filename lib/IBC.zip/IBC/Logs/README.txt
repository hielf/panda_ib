You can delete the files in this folder at any time

Windows will inform you if a file is currently in use
when you try to delete it.
